# Copyright 2019-2026 ETH Zurich and the DaCe authors. All rights reserved.
""" A module that contains various DaCe type definitions. """
import ctypes
import json
import inspect
import numpy
import re
from sympy import Float, Integer
from collections import OrderedDict
from functools import wraps
from typing import Any, Dict, TYPE_CHECKING

from dace.config import Config

from enum import auto, Enum
from dace.attr_enum import ExtensibleAttributeEnum
from dace.registry import undefined_safe_enum


@undefined_safe_enum
class DeviceType(ExtensibleAttributeEnum):
    CPU = auto()  #: Multi-core CPU
    GPU = auto()  #: GPU (AMD or NVIDIA)
    Snitch = auto()  #: Compute Cluster (RISC-V)


@undefined_safe_enum
class StorageType(ExtensibleAttributeEnum):
    """ Available data storage types in the SDFG. """

    Default = auto()  #: Scope-default storage location
    Register = auto()  #: Local data on registers, stack, or equivalent memory
    CPU_Pinned = auto()  #: Host memory that can be DMA-accessed from accelerators
    CPU_Heap = auto()  #: Host memory allocated on heap
    CPU_ThreadLocal = auto()  #: Thread-local host memory
    GPU_Global = auto()  #: GPU global memory
    GPU_Shared = auto()  #: On-GPU shared memory
    SVE_Register = auto()  #: SVE register
    Snitch_TCDM = auto()  #: Cluster-private memory
    Snitch_L2 = auto()  #: External memory
    Snitch_SSR = auto()  #: Memory accessed by SSR streamer


class OMPScheduleType(Enum):
    """ Available OpenMP shedule types for Maps with CPU-Multicore schedule. """
    Default = auto()  #: OpenMP library default
    Static = auto()  #: Static schedule
    Dynamic = auto()  #: Dynamic schedule
    Guided = auto()  #: Guided schedule


@undefined_safe_enum
class ScheduleType(ExtensibleAttributeEnum):
    """ Available map schedule types in the SDFG. """
    Default = auto()  #: Scope-default parallel schedule
    Sequential = auto()  #: Sequential code (single-thread)
    MPI = auto()  #: MPI processes
    CPU_Multicore = auto()  #: OpenMP parallel for loop
    CPU_Persistent = auto()  #: OpenMP parallel region
    SVE_Map = auto()  #: Arm SVE

    GPU_Device = auto()  #: Kernel
    GPU_ThreadBlock = auto()  #: Thread-block code
    GPU_ThreadBlock_Dynamic = auto()  #: Allows rescheduling work within a block
    GPU_Persistent = auto()

    Snitch = auto()
    Snitch_Multicore = auto()


# A subset of GPU schedule types
GPU_SCHEDULES = [
    ScheduleType.GPU_Device,
    ScheduleType.GPU_ThreadBlock,
    ScheduleType.GPU_ThreadBlock_Dynamic,
    ScheduleType.GPU_Persistent,
]

# A subset of CPU schedule types
CPU_SCHEDULES = [
    ScheduleType.CPU_Multicore,
    ScheduleType.CPU_Persistent,
]

# A subset of on-GPU storage types
GPU_STORAGES = [
    StorageType.GPU_Shared,
]


class ReductionType(Enum):
    """ Reduction types natively supported by the SDFG compiler. """

    Custom = auto()  #: Defined by an arbitrary lambda function
    Min = auto()  #: Minimum value
    Max = auto()  #: Maximum value
    Sum = auto()  #: Sum
    Product = auto()  #: Product
    Logical_And = auto()  #: Logical AND (&&)
    Bitwise_And = auto()  #: Bitwise AND (&)
    Logical_Or = auto()  #: Logical OR (||)
    Bitwise_Or = auto()  #: Bitwise OR (|)
    Logical_Xor = auto()  #: Logical XOR (!=)
    Bitwise_Xor = auto()  #: Bitwise XOR (^)
    Min_Location = auto()  #: Minimum value and its location
    Max_Location = auto()  #: Maximum value and its location
    Exchange = auto()  #: Set new value, return old value

    # Only supported in OpenMP
    Sub = auto()  #: Subtraction (only supported in OpenMP)
    Div = auto()  #: Division (only supported in OpenMP)


class AllocationLifetime(Enum):
    """ Options for allocation span (when to allocate/deallocate) of data. """

    Scope = auto()  #: Allocated/Deallocated on innermost scope start/end
    State = auto()  #: Allocated throughout the containing state
    SDFG = auto()  #: Allocated throughout the innermost SDFG (possibly nested)
    Global = auto()  #: Allocated throughout the entire program (outer SDFG)
    Persistent = auto()  #: Allocated throughout multiple invocations (init/exit)
    External = auto()  #: Allocated and managed outside the generated code


@undefined_safe_enum
class Language(ExtensibleAttributeEnum):
    """ Available programming languages for SDFG tasklets. """

    Python = auto()
    CPP = auto()
    OpenCL = auto()
    SystemVerilog = auto()
    MLIR = auto()


@undefined_safe_enum
class InstrumentationType(ExtensibleAttributeEnum):
    """ Types of instrumentation providers. """

    No_Instrumentation = auto()
    Timer = auto()
    PAPI_Counters = auto()
    LIKWID_CPU = auto()
    LIKWID_GPU = auto()
    GPU_Events = auto()
    GPU_TX_MARKERS = auto()


@undefined_safe_enum
class DataInstrumentationType(ExtensibleAttributeEnum):
    """ Types of data container instrumentation providers. """

    No_Instrumentation = auto()
    Save = auto()
    Restore = auto()


class TilingType(Enum):
    """ Available tiling types in a `StripMining` transformation. """

    Normal = auto()
    CeilRange = auto()
    NumberOfTiles = auto()


# Maps from ScheduleType to default StorageType
SCOPEDEFAULT_STORAGE = {
    ScheduleType.Default: StorageType.Default,
    None: StorageType.CPU_Heap,
    ScheduleType.Sequential: StorageType.Register,
    ScheduleType.MPI: StorageType.CPU_Heap,
    ScheduleType.CPU_Multicore: StorageType.Register,
    ScheduleType.CPU_Persistent: StorageType.CPU_Heap,
    ScheduleType.GPU_Persistent: StorageType.GPU_Global,
    ScheduleType.GPU_Device: StorageType.GPU_Shared,
    ScheduleType.GPU_ThreadBlock: StorageType.Register,
    ScheduleType.GPU_ThreadBlock_Dynamic: StorageType.Register,
    ScheduleType.SVE_Map: StorageType.CPU_Heap,
    ScheduleType.Snitch: StorageType.Snitch_TCDM
}

# Maps from ScheduleType to default ScheduleType for sub-scopes
SCOPEDEFAULT_SCHEDULE = {
    ScheduleType.Default: ScheduleType.Default,
    None: ScheduleType.CPU_Multicore,
    ScheduleType.Sequential: ScheduleType.Sequential,
    ScheduleType.MPI: ScheduleType.CPU_Multicore,
    ScheduleType.CPU_Multicore: ScheduleType.Sequential,
    ScheduleType.CPU_Persistent: ScheduleType.CPU_Multicore,
    ScheduleType.GPU_Persistent: ScheduleType.GPU_Device,
    ScheduleType.GPU_Device: ScheduleType.GPU_ThreadBlock,
    ScheduleType.GPU_ThreadBlock: ScheduleType.Sequential,
    ScheduleType.GPU_ThreadBlock_Dynamic: ScheduleType.Sequential,
    ScheduleType.SVE_Map: ScheduleType.Sequential,
    ScheduleType.Snitch: ScheduleType.Snitch,
    ScheduleType.Snitch_Multicore: ScheduleType.Snitch_Multicore
}

# Maps from StorageType to a preferred ScheduleType for helping determine schedules.
# If mapped to None or does not exist in this dictionary, does not affect decision.
# Scalar data containers also do not affect this decision.
STORAGEDEFAULT_SCHEDULE = {
    StorageType.CPU_Heap: ScheduleType.CPU_Multicore,
    StorageType.CPU_ThreadLocal: ScheduleType.CPU_Multicore,
    StorageType.GPU_Global: ScheduleType.GPU_Device,
    StorageType.GPU_Shared: ScheduleType.GPU_ThreadBlock,
    StorageType.SVE_Register: ScheduleType.SVE_Map,
}

# Translation of types to C types
_CTYPES = {
    None: "void",
    int: "int",
    float: "float",
    complex: "dace::complex64",
    bool: "bool",
    numpy.bool_: "bool",
    numpy.int8: "int8_t",
    numpy.int16: "int16_t",
    numpy.int32: "int32_t",
    numpy.intc: "int",
    numpy.int64: "int64_t",
    numpy.uint8: "uint8_t",
    numpy.uint16: "uint16_t",
    numpy.uint32: "uint32_t",
    numpy.uintc: "dace::uint",
    numpy.uint64: "uint64_t",
    numpy.float16: "dace::float16",
    numpy.float32: "float",
    numpy.float64: "double",
    numpy.complex64: "dace::complex64",
    numpy.complex128: "dace::complex128",
}

# Translation of types to ctypes types
_FFI_CTYPES = {
    None: ctypes.c_void_p,
    int: ctypes.c_int,
    float: ctypes.c_float,
    complex: ctypes.c_uint64,
    bool: ctypes.c_bool,
    numpy.bool_: ctypes.c_bool,
    numpy.int8: ctypes.c_int8,
    numpy.int16: ctypes.c_int16,
    numpy.int32: ctypes.c_int32,
    numpy.int64: ctypes.c_int64,
    numpy.intc: ctypes.c_int,
    numpy.uint8: ctypes.c_uint8,
    numpy.uint16: ctypes.c_uint16,
    numpy.uint32: ctypes.c_uint32,
    numpy.uint64: ctypes.c_uint64,
    numpy.uintc: ctypes.c_uint,
    numpy.float16: ctypes.c_uint16,
    numpy.float32: ctypes.c_float,
    numpy.float64: ctypes.c_double,
    numpy.complex64: ctypes.c_uint64,
    numpy.complex128: ctypes.c_longdouble,
}

# Number of bytes per data type
_BYTES = {
    None: 0,
    int: 4,
    float: 4,
    complex: 8,
    bool: 1,
    numpy.bool_: 1,
    numpy.int8: 1,
    numpy.int16: 2,
    numpy.int32: 4,
    numpy.int64: 8,
    numpy.intc: 4,
    numpy.uint8: 1,
    numpy.uint16: 2,
    numpy.uint32: 4,
    numpy.uint64: 8,
    numpy.uintc: 4,
    numpy.float16: 2,
    numpy.float32: 4,
    numpy.float64: 8,
    numpy.complex64: 8,
    numpy.complex128: 16,
}


class typeclass(object):
    """ An extension of types that enables their use in DaCe.

        These types are defined for three reasons:
            1. Controlling DaCe types
            2. Enabling declaration syntax: `dace.float32[M,N]`
            3. Enabling extensions such as `dace.struct` and `dace.vector`
    """

    def __init__(self, wrapped_type, typename=None):
        # Convert python basic types
        if isinstance(wrapped_type, str):
            try:
                if wrapped_type == "bool":
                    wrapped_type = numpy.bool_
                else:
                    wrapped_type = getattr(numpy, wrapped_type)
            except AttributeError:
                raise ValueError("Unknown type: {}".format(wrapped_type))

        config_data_types = Config.get('compiler', 'default_data_types')

        if wrapped_type is int:
            if config_data_types.lower() == 'python':
                wrapped_type = numpy.int64
            elif config_data_types.lower() == 'c':
                wrapped_type = numpy.int32
            else:
                raise NameError("Unknown configuration for default_data_types: {}".format(config_data_types))
        elif wrapped_type is float:
            if config_data_types.lower() == 'python':
                wrapped_type = numpy.float64
            elif config_data_types.lower() == 'c':
                wrapped_type = numpy.float32
            else:
                raise NameError("Unknown configuration for default_data_types: {}".format(config_data_types))
        elif wrapped_type is complex:
            if config_data_types.lower() == 'python':
                wrapped_type = numpy.complex128
            elif config_data_types.lower() == 'c':
                wrapped_type = numpy.complex64
            else:
                raise NameError("Unknown configuration for default_data_types: {}".format(config_data_types))
        elif wrapped_type is bool:
            wrapped_type = numpy.bool_
        elif getattr(wrapped_type, '__name__', '') == 'bool_' and typename is None:
            typename = 'bool'
        elif wrapped_type is type(None):
            wrapped_type = None
        elif wrapped_type is Float:
            wrapped_type = float
        elif wrapped_type is Integer:
            wrapped_type = int

        self.type = wrapped_type  # Type in Python
        self.ctype = _CTYPES[wrapped_type]  # Type in C
        self.ctype_unaligned = self.ctype  # Type in C (without alignment)
        self.dtype = self  # For compatibility support with numpy
        self.bytes = _BYTES[wrapped_type]  # Number of bytes for this type
        self.typename = typename

    def __hash__(self):
        return hash((self.type, self.ctype))

    def to_string(self):
        """ A Numpy-like string-representation of the underlying data type. """
        return self.typename or self.type.__name__

    def as_ctypes(self):
        """ Returns the ctypes version of the typeclass. """
        return _FFI_CTYPES[self.type]

    def as_numpy_dtype(self):
        return numpy.dtype(self.type)

    def is_complex(self):
        if self.type == numpy.complex64 or self.type == numpy.complex128:
            return True
        return False

    def to_json(self):
        if self.type is None:
            return None
        return self.typename or self.type.__name__

    @staticmethod
    def from_json(json_obj, context=None):
        if json_obj is None:
            return typeclass(None)
        return json_to_typeclass(json_obj, context)

    # Create a new type
    def __call__(self, *args, **kwargs):
        return self.type(*args, **kwargs)

    def __eq__(self, other):
        return other is not None and self.ctype == other.ctype

    def __ne__(self, other):
        return other is not None and self.ctype != other.ctype

    def __getitem__(self, s):
        """ This is syntactic sugar that allows us to define an array type
            with the following syntax: ``dace.uint32[N,M]``

            :return: A ``data.Array`` data descriptor.
        """
        from dace import data

        if isinstance(s, list) or isinstance(s, tuple):
            return data.Array(self, tuple(s))
        return data.Array(self, (s, ))

    def __repr__(self):
        return self.ctype

    @property
    def base_type(self):
        return self

    @property
    def veclen(self):
        return 1

    def as_arg(self, name):
        return self.ctype + ' ' + name


def max_value(dtype: typeclass):
    """Get a max value literal for `dtype`."""
    nptype = dtype.as_numpy_dtype()
    if nptype == numpy.bool_:
        return True
    elif numpy.issubdtype(nptype, numpy.integer):
        return numpy.iinfo(nptype).max
    elif numpy.issubdtype(nptype, numpy.floating):
        return numpy.finfo(nptype).max

    raise TypeError('Unsupported type "%s" for maximum' % dtype)


def min_value(dtype: typeclass):
    """Get a min value literal for `dtype`."""
    nptype = dtype.as_numpy_dtype()
    if nptype == numpy.bool_:
        return False
    elif numpy.issubdtype(nptype, numpy.integer):
        return numpy.iinfo(nptype).min
    elif numpy.issubdtype(nptype, numpy.floating):
        return numpy.finfo(nptype).min

    raise TypeError('Unsupported type "%s" for minimum' % dtype)


def reduction_identity(dtype: typeclass, red: ReductionType) -> Any:
    """
    Returns known identity values (which we can safely reset transients to)
    for built-in reduction types.

    :param dtype: Input type.
    :param red: Reduction type.
    :return: Identity value in input type, or None if not found.
    """
    _VALUE_GENERATORS = {
        ReductionType.Custom: lambda x: None,
        ReductionType.Min: max_value,
        ReductionType.Max: min_value,
        ReductionType.Sum: lambda x: x(0),
        ReductionType.Product: lambda x: x(1),
        ReductionType.Logical_And: lambda x: x(True),
        ReductionType.Logical_Or: lambda x: x(False),
        ReductionType.Bitwise_And: lambda x: ~x(0),
        ReductionType.Bitwise_Or: lambda x: x(0),
    }
    if red not in _VALUE_GENERATORS:
        return None
    return _VALUE_GENERATORS[red](dtype)


def result_type_of(lhs, *rhs):
    """
    Returns the largest between two or more types (dace.types.typeclass)
    according to C semantics.
    """
    if len(rhs) == 0:
        rhs = None
    elif len(rhs) > 1:
        result = lhs
        for r in rhs:
            result = result_type_of(result, r)
        return result

    rhs = rhs[0]

    # Extract the type if symbolic or data
    from dace.data import Data
    lhs = lhs.dtype if (type(lhs).__name__ == 'symbol' or isinstance(lhs, Data)) else lhs
    rhs = rhs.dtype if (type(rhs).__name__ == 'symbol' or isinstance(rhs, Data)) else rhs

    if lhs == rhs:
        return lhs  # Types are the same, return either
    if lhs is None or lhs.type is None:
        return rhs  # Use RHS even if it's None
    if rhs is None or rhs.type is None:
        return lhs  # Use LHS

    # Vector types take precedence, largest vector size first
    if isinstance(lhs, vector) and not isinstance(rhs, vector):
        return lhs
    elif not isinstance(lhs, vector) and isinstance(rhs, vector):
        return rhs
    elif isinstance(lhs, vector) and isinstance(rhs, vector):
        if lhs.veclen == rhs.veclen:
            return vector(result_type_of(lhs.vtype, rhs.vtype), lhs.veclen)
        return lhs if lhs.veclen > rhs.veclen else rhs

    # Extract the numpy type so we can call issubdtype on them
    lhs_ = lhs.type if isinstance(lhs, typeclass) else lhs
    rhs_ = rhs.type if isinstance(rhs, typeclass) else rhs
    # Extract data sizes (seems the type itself doesn't expose this)
    size_lhs = lhs_(0).itemsize
    size_rhs = rhs_(0).itemsize
    # Both are integers
    if numpy.issubdtype(lhs_, numpy.integer) and numpy.issubdtype(rhs_, numpy.integer):
        # If one byte width is larger, use it
        if size_lhs > size_rhs:
            return lhs
        elif size_lhs < size_rhs:
            return rhs
        # Sizes are the same
        if numpy.issubdtype(lhs_, numpy.unsignedinteger):
            # No matter if right is signed or not, we must return unsigned
            return lhs
        else:
            # Left is signed, so either right is unsigned and we return that,
            # or both are signed
            return rhs
    # At least one side is a floating point number
    if numpy.issubdtype(lhs_, numpy.integer):
        return rhs
    if numpy.issubdtype(rhs_, numpy.integer):
        return lhs
    # Both sides are floating point numbers
    if size_lhs > size_rhs:
        return lhs
    return rhs  # RHS is bigger


class opaque(typeclass):
    """ A data type for an opaque object, useful for C bindings/libnodes, i.e., MPI_Request. """

    def __init__(self, typename):
        self.type = typename
        self.ctype = typename
        self.ctype_unaligned = typename
        self.dtype = self

    def to_json(self):
        return {'type': 'opaque', 'ctype': self.ctype}

    @staticmethod
    def from_json(json_obj, context=None):
        if json_obj['type'] != 'opaque':
            raise TypeError("Invalid type for opaque object")

        try:
            typeclass = json_to_typeclass(json_obj['ctype'], context)
            return typeclass()
        except KeyError:
            typeclass = json_obj['ctype']

        return opaque(typeclass)

    def as_ctypes(self):
        """ Returns the ctypes version of the typeclass. """
        return self

    def as_numpy_dtype(self):
        raise NotImplementedError("Not sure how to make a numpy type from an opaque C type.")


class pointer(typeclass):
    """ A data type for a pointer to an existing typeclass.

        Example use:
            `dace.pointer(dace.struct(x=dace.float32, y=dace.float32))`. """

    def __init__(self, wrapped_typeclass):
        self._typeclass = wrapped_typeclass
        self.type = wrapped_typeclass.type
        self.bytes = ctypes.sizeof(ctypes.c_void_p)
        self.ctype = wrapped_typeclass.ctype + "*"
        self.ctype_unaligned = wrapped_typeclass.ctype_unaligned + "*"
        self.dtype = self

    def to_json(self):
        return {'type': 'pointer', 'dtype': self._typeclass.to_json()}

    @staticmethod
    def from_json(json_obj, context=None):
        if json_obj['type'] != 'pointer':
            raise TypeError("Invalid type for pointer")

        if json_obj['dtype'] is None:
            return pointer(typeclass(None))

        return pointer(json_to_typeclass(json_obj['dtype'], context))

    def as_ctypes(self):
        """ Returns the ctypes version of the typeclass. """
        if isinstance(self._typeclass, struct):
            return ctypes.POINTER(self._typeclass.as_ctypes())
        return ctypes.POINTER(_FFI_CTYPES[self.type])

    def as_numpy_dtype(self):
        return numpy.dtype(self.as_ctypes())

    @property
    def base_type(self):
        return self._typeclass


class vector(typeclass):
    """
    A data type for a vector-type of an existing typeclass.

    Example use: `dace.vector(dace.float32, 4)` becomes float4.
    """

    def __init__(self, dtype: typeclass, vector_length: int):
        self.vtype = dtype
        self.type = dtype.type
        self._veclen = vector_length
        self.bytes = dtype.bytes * vector_length
        self.dtype = self

    def to_json(self):
        return {'type': 'vector', 'dtype': self.vtype.to_json(), 'elements': str(self.veclen)}

    @staticmethod
    def from_json(json_obj, context=None):
        from dace.symbolic import pystr_to_symbolic
        return vector(json_to_typeclass(json_obj['dtype'], context), pystr_to_symbolic(json_obj['elements']))

    @property
    def ctype(self):
        return "dace::vec<%s, %s>" % (self.vtype.ctype, self.veclen)

    @property
    def ctype_unaligned(self):
        return self.ctype

    def as_ctypes(self):
        """ Returns the ctypes version of the typeclass. """
        return _FFI_CTYPES[self.type] * self.veclen

    def as_numpy_dtype(self):
        return numpy.dtype(self.as_ctypes())

    @property
    def base_type(self):
        return self.vtype

    @property
    def veclen(self):
        return self._veclen

    @veclen.setter
    def veclen(self, val):
        self._veclen = val


class stringtype(pointer):
    """
    A specialization of the string data type to improve
    Python/generated code marshalling.
    Used internally when `str` types are given
    """

    def __init__(self):
        super().__init__(int8)

    def __call__(self, *args, **kwargs):
        return str(*args, **kwargs)

    def to_json(self):
        return {'type': 'string'}

    @staticmethod
    def from_json(json_obj, context=None):
        return stringtype()


class struct(typeclass):
    """ A data type for a struct of existing typeclasses.

        Example use: `dace.struct(a=dace.int32, b=dace.float64)`.
    """
    STRUCT_CTYPES: Dict[str, ctypes.Structure] = {}

    def __init__(self, name, **fields_and_types):
        # self._data = fields_and_types
        self.type = ctypes.Structure
        self.name = name
        # TODO: Assuming no alignment! Get from ctypes
        # self.bytes = sum(t.bytes for t in fields_and_types.values())
        self.ctype = name
        self.ctype_unaligned = name
        self.dtype = self
        self._parse_field_and_types(**fields_and_types)

    @classmethod
    def __class_getitem__(cls, args):
        if not isinstance(args, tuple) or len(args) != 2:
            raise ValueError("struct type must be subscripted with (name, {field: type, ...})")
        name, fields_and_types = args
        if not isinstance(fields_and_types, dict):
            raise ValueError("struct type must be subscripted with (name, {field: type, ...})")
        return struct(name, **fields_and_types)

    @property
    def fields(self):
        return self._data

    def to_json(self):
        return {
            'type': 'struct',
            'name': self.name,
            'data': [(k, v.to_json()) for k, v in self._data.items()],
            'length': [(k, v) for k, v in self._length.items()],
            'bytes': self.bytes
        }

    @staticmethod
    def from_json(json_obj, context=None):
        if json_obj['type'] != "struct":
            raise TypeError("Invalid type for struct")

        import dace.serialize  # Avoid import loop

        ret = struct(json_obj['name'])
        ret._data = {k: json_to_typeclass(v, context) for k, v in json_obj['data']}
        ret._length = {k: v for k, v in json_obj['length']}
        ret.bytes = json_obj['bytes']

        return ret

    def _parse_field_and_types(self, **fields_and_types):
        # from dace.symbolic import pystr_to_symbolic
        self._data = OrderedDict()
        self._length = OrderedDict()
        self.bytes = 0
        for k, v in fields_and_types.items():
            if isinstance(v, tuple):
                t, l = v
                if not isinstance(t, pointer):
                    raise TypeError("Only pointer types may have a length.")
                # TODO: Do we need the free symbols of the length in the struct?
                # NOTE: It is needed for the old use of dtype.struct. Are we deprecating that?
                # sym_tokens = pystr_to_symbolic(l).free_symbols
                # for sym in sym_tokens:
                #     if str(sym) not in fields_and_types.keys():
                #         raise ValueError(f"Symbol {sym} in {k}'s length {l} is not a field of struct {self.name}")
                self._data[k] = t
                self._length[k] = l
                self.bytes += t.bytes
            else:
                if isinstance(v, pointer):
                    raise TypeError("Pointer types must have a length.")
                self._data[k] = v
                self.bytes += v.bytes

    def as_ctypes(self):
        """ Returns the ctypes version of the typeclass. """
        self_as_json = json.dumps(self.to_json(), sort_keys=True, separators=(',', ':'))
        if self_as_json in struct.STRUCT_CTYPES:
            return struct.STRUCT_CTYPES[self_as_json]
        # Populate the ctype fields for the struct class.
        fields = []
        for k, v in self._data.items():
            if isinstance(v, pointer):
                if isinstance(v._typeclass, struct):
                    fields.append((k, ctypes.POINTER(v._typeclass.as_ctypes())))
                else:
                    fields.append((k, ctypes.c_void_p))
            elif isinstance(v, struct):
                fields.append((k, v.as_ctypes()))
            else:
                fields.append((k, _FFI_CTYPES[v.type]))
        # Create new struct class.
        struct_class = type(self.name or "NewStructClass", (ctypes.Structure, ), {"_fields_": fields})
        # NOTE: Each call to `type` returns a different class, so we need to cache it to ensure uniqueness.
        struct.STRUCT_CTYPES[self_as_json] = struct_class

        if hasattr(self, "__descriptor__"):
            struct_class.__descriptor__ = self.__descriptor__

        return struct_class

    def as_numpy_dtype(self):
        return numpy.dtype(self.as_ctypes())

    def emit_definition(self):
        return """struct {name} {{
{typ}
}};""".format(
            name=self.name,
            typ='\n'.join(["    %s %s;" % (t.ctype, tname) for tname, t in self._data.items()]),
        )


class pyobject(opaque):
    """
    A generic data type for Python objects in un-annotated callbacks.
    It cannot be used inside a DaCe program, but can be passed back to other Python callbacks.
    Use with caution, and ensure the value is not removed by the garbage collector or the program will crash.
    """

    def __init__(self):
        super().__init__('pyobject')
        self.bytes = ctypes.sizeof(ctypes.c_void_p)
        self.type = numpy.object_

    def as_ctypes(self):
        return ctypes.py_object

    def as_numpy_dtype(self):
        return numpy.dtype(numpy.object_)

    def to_python(self, obj_id: int):
        return ctypes.cast(obj_id, ctypes.py_object).value


class compiletime:
    """
    Data descriptor type hint signalling that argument evaluation is
    deferred to call time.

    Example usage::

        @dace.program
        def example(A: dace.float64[20], constant: dace.compiletime):
            if constant == 0:
                return A + 1
            else:
                return A + 2


    In the above code, ``constant`` will be replaced with its value at call time
    during parsing.
    """

    @staticmethod
    def __descriptor__():
        raise ValueError('All compile-time arguments must be provided in order to compile the SDFG ahead-of-time.')


####### Utility function ##############
def ptrtonumpy(ptr, inner_ctype, shape):
    import ctypes
    return numpy.ctypeslib.as_array(ctypes.cast(ctypes.c_void_p(ptr), ctypes.POINTER(inner_ctype)), shape)


def ptrtocupy(ptr, inner_ctype, shape):
    import cupy as cp
    umem = cp.cuda.UnownedMemory(ptr, 0, None)
    return cp.ndarray(shape=shape, dtype=inner_ctype, memptr=cp.cuda.MemoryPointer(umem, 0))


class callback(typeclass):
    """
    Looks like ``dace.callback([None, <some_native_type>], *types)``
    """

    def __init__(self, return_types, *variadic_args):
        from dace import data
        if return_types is None:
            return_types = []
        elif not isinstance(return_types, (list, tuple, set)):
            return_types = [return_types]
        self.dtype = self
        self.return_types = return_types
        self.input_types = []
        for arg in variadic_args:
            if isinstance(arg, typeclass):
                pass
            elif isinstance(arg, data.Data):
                pass
            elif isinstance(arg, str):
                arg = json_to_typeclass(arg)
            else:
                raise TypeError("Cannot resolve type from: {}".format(arg))
            self.input_types.append(arg)
        self.bytes = int64.bytes
        self.type = self
        self.ctype = self

    def as_ctypes(self):
        """ Returns the ctypes version of the typeclass. """
        from dace import data

        return_ctype = self.cfunc_return_type().as_ctypes() if len(self.return_types) > 0 else None
        input_ctypes = []

        for some_arg in self.input_types:
            if isinstance(some_arg, data.Array):
                input_ctypes.append(ctypes.c_void_p)
            else:
                input_ctypes.append(some_arg.dtype.as_ctypes() if some_arg is not None else None)

        if not self.is_scalar_function():
            for some_arg in self.return_types:
                if isinstance(some_arg, data.Array):
                    input_ctypes.append(ctypes.c_void_p)
                else:
                    input_ctypes.append(pointer(some_arg.dtype).as_ctypes() if some_arg is not None else None)

        if input_ctypes == [None]:
            input_ctypes = []
        cf_object = ctypes.CFUNCTYPE(return_ctype, *input_ctypes)
        return cf_object

    def is_scalar_function(self) -> bool:
        """
        Returns True if the callback is a function that returns a scalar
        value (or nothing). Scalar functions are the only ones that can be
        used within a `dace.tasklet` explicitly.
        """
        from dace import data
        if len(self.return_types) == 0 or self.return_types == [None]:
            return True
        return (len(self.return_types) == 1 and isinstance(self.return_types[0], (typeclass, data.Scalar)))

    def cfunc_return_type(self) -> typeclass:
        """
        Returns the typeclass of the return value of the function call.
        """
        if len(self.return_types) == 0 or self.return_types == [None]:
            return typeclass(None)
        if not self.is_scalar_function():
            return typeclass(None)

        return self.return_types[0].dtype

    def as_numpy_dtype(self):
        return numpy.dtype(self.as_ctypes())

    def as_arg(self, name):
        from dace import data

        input_type_cstring = []

        for arg in self.input_types:
            if arg is None:
                continue
            if isinstance(arg, data.Array):
                # const hack needed to prevent error in casting const int* to int*
                input_type_cstring.append(arg.dtype.ctype + " const *")
            else:
                input_type_cstring.append(arg.ctype)

        if not self.is_scalar_function():
            for arg in self.return_types:
                if arg is None:
                    continue
                if isinstance(arg, data.Array):
                    # const hack needed to prevent error in casting const int* to int*
                    input_type_cstring.append(arg.dtype.ctype + " const *")
                else:
                    input_type_cstring.append(pointer(arg.dtype).ctype)

        retval = self.cfunc_return_type()
        return f'{retval} (*{name})({", ".join(input_type_cstring)})'

    def get_trampoline(self, pyfunc, other_arguments, refs, argument_to_pyobject):
        from functools import partial
        from dace import data, symbolic

        def _string_converter(a: str, *args):
            tmp = ctypes.cast(a, ctypes.c_char_p).value.decode('utf-8')
            if tmp.startswith(chr(0xFFFF)):
                return bytes(tmp[1:], 'utf-8')
            return tmp

        def _pyobject_converter(arg: data.Data, a: int, *args):
            try:
                if argument_to_pyobject is not None and a in argument_to_pyobject:
                    # Avoid views of the same object from using the original one
                    if arg.is_equivalent(argument_to_pyobject[a][1]):
                        return argument_to_pyobject[a][0]
            except TypeError:  # Unhashable type
                pass
            return data.make_reference_from_descriptor(arg, a, *args)

        inp_arraypos = []
        ret_arraypos = []
        inp_types_and_sizes = []
        ret_types_and_sizes = []
        inp_converters = []
        ret_converters = []
        for index, arg in enumerate(self.input_types):
            if isinstance(arg, data.Array):
                inp_arraypos.append(index)
                inp_types_and_sizes.append((arg.dtype.as_ctypes(), arg.shape))
                inp_converters.append(partial(_pyobject_converter, arg))
            elif isinstance(arg, data.Scalar) and arg.dtype == string:
                inp_arraypos.append(index)
                inp_types_and_sizes.append((ctypes.c_char_p, []))
                inp_converters.append(_string_converter)
            elif isinstance(arg, data.Scalar) and isinstance(arg.dtype, pointer):
                inp_arraypos.append(index)
                inp_types_and_sizes.append((ctypes.c_void_p, []))
                inp_converters.append(lambda a, *args: ctypes.cast(a, ctypes.c_void_p).value)
            elif isinstance(arg, data.Scalar) and isinstance(arg.dtype, pyobject):
                inp_arraypos.append(index)
                inp_types_and_sizes.append((ctypes.py_object, []))
                inp_converters.append(lambda a, *args: a)
            else:
                inp_converters.append(lambda a, *args: a)
        offset = len(self.input_types)
        for index, arg in enumerate(self.return_types):
            if isinstance(arg, data.Array):
                ret_arraypos.append(index + offset)
                ret_types_and_sizes.append((arg.dtype.as_ctypes(), arg.shape))
                ret_converters.append(partial(_pyobject_converter, arg))
            elif isinstance(arg, data.Scalar) and arg.dtype == string:
                ret_arraypos.append(index + offset)
                ret_types_and_sizes.append((ctypes.c_char_p, []))
                ret_converters.append(lambda a, *args: ctypes.cast(a, ctypes.c_char_p).value.decode('utf-8'))
            elif isinstance(arg, data.Scalar) and isinstance(arg.dtype, pointer):
                ret_arraypos.append(index + offset)
                ret_types_and_sizes.append((ctypes.c_void_p, []))
                ret_converters.append(lambda a, *args: ctypes.cast(a, ctypes.c_void_p).value)
            elif isinstance(arg, data.Scalar) and isinstance(arg.dtype, pyobject):
                ret_arraypos.append(index + offset)
                ret_types_and_sizes.append((ctypes.py_object, []))
                ret_converters.append(lambda a, *args: a)
            else:
                if not self.is_scalar_function():
                    ret_arraypos.append(index + offset)
                    ret_types_and_sizes.append((arg.dtype.as_ctypes(), arg.shape))
                    ret_converters.append(partial(_pyobject_converter, arg))
                else:
                    ret_converters.append(lambda a, *args: a)
        if len(inp_arraypos) == 0 and len(ret_arraypos) == 0:
            return pyfunc

        def trampoline(orig_function, indices, data_types_and_sizes, ret_indices, ret_data_types_and_sizes,
                       *other_inputs):
            last_input = len(other_inputs)
            if ret_indices:
                last_input = ret_indices[0]
            list_of_other_inputs = list(other_inputs[:last_input])
            list_of_outputs = []
            if ret_indices:
                list_of_outputs = list(other_inputs[last_input:])
            for j, i in enumerate(indices):
                data_type, size = data_types_and_sizes[j]
                non_symbolic_sizes = []
                for s in size:
                    if isinstance(s, symbolic.symbol):
                        non_symbolic_sizes.append(other_arguments[str(s)])
                    else:
                        non_symbolic_sizes.append(s)
                list_of_other_inputs[i] = inp_converters[i](other_inputs[i], other_arguments)
            if list_of_outputs:
                for j, i in enumerate(ret_indices):
                    data_type, size = ret_data_types_and_sizes[j]
                    non_symbolic_sizes = []
                    for s in size:
                        if isinstance(s, symbolic.symbol):
                            non_symbolic_sizes.append(other_arguments[str(s)])
                        else:
                            non_symbolic_sizes.append(s)
                    outind = i - last_input
                    if len(other_inputs) > i:
                        list_of_outputs[outind] = ret_converters[outind](other_inputs[i], other_arguments)
                    else:
                        list_of_outputs[outind] = None

            if ret_indices:
                ret = orig_function(*list_of_other_inputs)
                if len(list_of_outputs) == 0:
                    if refs is not None:
                        refs.append(ret)  # Keep reference so that garbage collection does not free object
                    return ret_converters[0](ret, other_arguments)
                elif len(list_of_outputs) == 1:
                    ret = [ret]
                for v, r in zip(list_of_outputs, ret):
                    if v is not None:  # Was converted to an assignable pointer
                        v[:] = r

                    if refs is not None:
                        refs.append(r)  # Keep reference so that garbage collection does not free object
                return
            return orig_function(*list_of_other_inputs)

        return partial(trampoline, pyfunc, inp_arraypos, inp_types_and_sizes, ret_arraypos, ret_types_and_sizes)

    def __hash__(self):
        return hash((*self.return_types, *self.input_types))

    def to_json(self):
        if self.return_types:
            return {
                'type': 'callback',
                'arguments': [i.to_json() for i in self.input_types],
                'returntypes': [r.to_json() for r in self.return_types]
            }
        return {'type': 'callback', 'arguments': [i.to_json() for i in self.input_types], 'returntypes': []}

    @staticmethod
    def from_json(json_obj, context=None):
        if json_obj['type'] != "callback":
            raise TypeError("Invalid type for callback")

        rettypes = json_obj['returntypes']

        import dace.serialize  # Avoid import loop

        return callback([json_to_typeclass(rettype) if rettype else None for rettype in rettypes],
                        *(dace.serialize.from_json(arg, context) for arg in json_obj['arguments']))

    def __str__(self):
        return "dace.callback"

    def __repr__(self):
        return "dace.callback"

    def __eq__(self, other):
        if not isinstance(other, callback):
            return False
        return self.input_types == other.input_types and self.return_types == other.return_types

    def __ne__(self, other):
        return not self.__eq__(other)


# Helper function to determine whether a global variable is a constant
_CONSTANT_TYPES = [
    type(None),
    int,
    float,
    complex,
    str,
    bool,
    slice,
    numpy.bool_,
    numpy.intc,
    numpy.intp,
    numpy.int8,
    numpy.int16,
    numpy.int32,
    numpy.int64,
    numpy.uint8,
    numpy.uint16,
    numpy.uint32,
    numpy.uint64,
    numpy.float16,
    numpy.float32,
    numpy.float64,
    numpy.complex64,
    numpy.complex128,
    typeclass,  # , type
]


def isconstant(var):
    """ Returns True if a variable is designated a constant (i.e., that can be
        directly generated in code).
    """
    return type(var) in _CONSTANT_TYPES


if TYPE_CHECKING:
    # Type stubs for type checkers
    import numpy.typing as npt
    from typing_extensions import Self

    # yapf: disable
    # Type stub base: NDArray that accepts symbolic shape subscripts like [M, N].
    class _DaCeArray(npt.NDArray):
        def __class_getitem__(cls, item: object) -> type[Self]: ...

    # DaCe scalar types: when subscripted, behave as typed NDArrays
    class bool_(_DaCeArray, npt.NDArray[numpy.bool_]): ...
    class int8(_DaCeArray, npt.NDArray[numpy.int8]): ...
    class int16(_DaCeArray, npt.NDArray[numpy.int16]): ...
    class int32(_DaCeArray, npt.NDArray[numpy.int32]): ...
    class int64(_DaCeArray, npt.NDArray[numpy.int64]): ...
    class uintp(_DaCeArray, npt.NDArray[numpy.uintp]): ...
    class uint8(_DaCeArray, npt.NDArray[numpy.uint8]): ...
    class uint16(_DaCeArray, npt.NDArray[numpy.uint16]): ...
    class uint32(_DaCeArray, npt.NDArray[numpy.uint32]): ...
    class uint64(_DaCeArray, npt.NDArray[numpy.uint64]): ...
    class float16(_DaCeArray, npt.NDArray[numpy.float16]): ...
    class float32(_DaCeArray, npt.NDArray[numpy.float32]): ...
    class float64(_DaCeArray, npt.NDArray[numpy.float64]): ...
    class complex64(_DaCeArray, npt.NDArray[numpy.complex64]): ...
    class complex128(_DaCeArray, npt.NDArray[numpy.complex128]): ...
    class string(_DaCeArray, npt.NDArray[numpy.str_]): ...
    class vector(_DaCeArray, npt.NDArray[numpy.void]): ...
    class MPI_Request(_DaCeArray, npt.NDArray[numpy.void]): ...
    # yapf: enable
else:
    # Runtime definitions
    bool_ = typeclass(numpy.bool_, 'bool')
    int8 = typeclass(numpy.int8)
    int16 = typeclass(numpy.int16)
    int32 = typeclass(numpy.int32)
    int64 = typeclass(numpy.int64)
    uintp = typeclass(numpy.uintp)
    uint8 = typeclass(numpy.uint8)
    uint16 = typeclass(numpy.uint16)
    uint32 = typeclass(numpy.uint32)
    uint64 = typeclass(numpy.uint64)
    float16 = typeclass(numpy.float16)
    float32 = typeclass(numpy.float32)
    float64 = typeclass(numpy.float64)
    complex64 = typeclass(numpy.complex64)
    complex128 = typeclass(numpy.complex128)
    string = stringtype()
    MPI_Request = opaque('MPI_Request')

_bool = bool


def dtype_to_typeclass(dtype=None):
    DTYPE_TO_TYPECLASS = {
        _bool: typeclass(_bool),
        int: typeclass(int),
        float: typeclass(float),
        complex: typeclass(complex),
        numpy.bool_: bool_,
        numpy.int8: int8,
        numpy.int16: int16,
        numpy.int32: int32,
        numpy.int64: int64,
        numpy.intc: int32,
        numpy.uint8: uint8,
        numpy.uint16: uint16,
        numpy.uint32: uint32,
        numpy.uint64: uint64,
        numpy.uintc: uint32,
        numpy.float16: float16,
        numpy.float32: float32,
        numpy.float64: float64,
        numpy.complex64: complex64,
        numpy.complex128: complex128,
        # FIXME
        numpy.longlong: int64,
        numpy.ulonglong: uint64
    }
    if dtype is None:
        return DTYPE_TO_TYPECLASS
    return DTYPE_TO_TYPECLASS[dtype]


# Since this overrides the builtin bool, this should be after the
# DTYPE_TO_TYPECLASS dictionary
bool = bool_

TYPECLASS_TO_STRING = {
    bool: "dace::bool_",
    bool_: "dace::bool_",
    uint8: "dace::uint8",
    uint16: "dace::uint16",
    uint32: "dace::uint32",
    uint64: "dace::uint64",
    int8: "dace::int8",
    int16: "dace::int16",
    int32: "dace::int32",
    int64: "dace::int64",
    float16: "dace::float16",
    float32: "dace::float32",
    float64: "dace::float64",
    complex64: "dace::complex64",
    complex128: "dace::complex128"
}

TYPECLASS_STRINGS = [
    "int", "float", "complex", "bool", "bool_", "int8", "int16", "int32", "int64", "uint8", "uint16", "uint32",
    "uint64", "float16", "float32", "float64", "complex64", "complex128"
]

INTEGER_TYPES = [bool, bool_, int8, int16, int32, int64, uint8, uint16, uint32, uint64]

#######################################################
# Allowed types

# Lists allowed modules and maps them to C++ namespaces for code generation
_ALLOWED_MODULES = {
    "builtins": "",
    "dace": "dace::",
    "math": "dace::math::",
    "cmath": "dace::cmath::",
}


def ismodule(var):
    """ Returns True if a given object is a module. """
    return inspect.ismodule(var)


def ismoduleallowed(var):
    """ Helper function to determine the source module of an object, and
        whether it is allowed in DaCe programs. """
    mod = inspect.getmodule(var)
    try:
        for m in _ALLOWED_MODULES:
            if mod.__name__ == m or mod.__name__.startswith(m + "."):
                return True
    except AttributeError:
        return False
    return False


def ismodule_and_allowed(var):
    """ Returns True if a given object is a module and is one of the allowed
        modules in DaCe programs. """
    if inspect.ismodule(var):
        if var.__name__ in _ALLOWED_MODULES:
            return True
    return False


def isallowed(var, allow_recursive=False):
    """ Returns True if a given object is allowed in a DaCe program.

        :param allow_recursive: whether to allow dicts or lists containing constants.
    """
    from dace.symbolic import issymbolic

    if allow_recursive:
        if isinstance(var, (list, tuple)):
            return all(isallowed(v, allow_recursive=False) for v in var)

    return isconstant(var) or ismodule(var) or issymbolic(var) or isinstance(var, typeclass)


class DebugInfo:
    """ Source code location identifier of a node/edge in an SDFG. Used for
        IDE and debugging purposes. """

    def __init__(self, start_line, start_column=0, end_line=-1, end_column=0, filename=None, file_index=None):
        self.start_line = start_line
        self.end_line = end_line if end_line >= 0 else start_line
        self.start_column = start_column
        self.end_column = end_column

        if filename is not None and file_index is not None:
            raise ValueError("Cannot specify both filename and file_index in DebugInfo")

        self.filename = filename
        self.file_index = file_index

    # NOTE: Manually marking as serializable to avoid an import loop
    # The data structure is a property on its own (pointing to a range of code),
    # so it is serialized as a dictionary directly.
    def to_json(self):
        result = {'type': 'DebugInfo'}
        if self.start_line is not None:
            result['start_line'] = self.start_line
        if self.end_line is not None and self.end_line != self.start_line:
            result['end_line'] = self.end_line
        if self.start_column:
            result['start_column'] = self.start_column
        if self.end_column and self.end_column != self.start_column:
            result['end_column'] = self.end_column
        if self.file_index is not None:
            result['file_index'] = self.file_index
        elif self.filename:
            result['filename'] = self.filename

        return result

    @staticmethod
    def from_json(json_obj: dict[str, int | str], context=None):
        return DebugInfo(json_obj.get('start_line'), json_obj.get('start_column', 0), json_obj.get('end_line', -1),
                         json_obj.get('end_column', 0), json_obj.get('filename'), json_obj.get('file_index'))

    def __deepcopy__(self, memo) -> 'DebugInfo':
        """Performs a `deepcopy` of `self`.

        Because all members of `self` are immutable this function is essentially a shallow copy.
        """
        new = object.__new__(DebugInfo)
        new.__dict__.update(self.__dict__)
        return new


######################################################
# Static (utility) functions


def json_to_typeclass(obj, context=None):
    # TODO: this does two different things at the same time. Should be split
    # into two separate functions.
    from dace.serialize import get_serializer
    if isinstance(obj, str):
        return get_serializer(obj)
    elif isinstance(obj, dict) and "type" in obj:
        return get_serializer(obj["type"]).from_json(obj, context)
    else:
        raise ValueError("Cannot resolve: {}".format(obj))


def paramdec(dec):
    """ Parameterized decorator meta-decorator. Enables using `@decorator`,
        `@decorator()`, and `@decorator(...)` with the same function. """

    @wraps(dec)
    def layer(*args, **kwargs):
        from dace import data
        # Allows the use of @decorator, @decorator(), and @decorator(...)
        if (len(kwargs) == 0 and len(args) == 1 and callable(args[0])
                and not isinstance(args[0], (typeclass, data.Data))):
            return dec(*args, **kwargs)

        @wraps(dec)
        def repl(f):
            return dec(f, *args, **kwargs)

        return repl

    return layer


#############################################


def deduplicate(iterable):
    """ Removes duplicates in the passed iterable. """
    return type(iterable)([i for i in sorted(set(iterable), key=lambda x: iterable.index(x))])


namere = re.compile(r'^[a-zA-Z_][a-zA-Z_0-9]*$')


def validate_name(name):
    if not isinstance(name, str) or len(name) == 0:
        return False
    if name in {'True', 'False', 'None'}:
        return False
    tokens = name.split('.')
    for token in tokens:
        if namere.match(token) is None:
            return False
    return True


def can_access(schedule: ScheduleType, storage: StorageType):
    """
    Identifies whether a container of a storage type can be accessed in a specific schedule.
    """
    if storage == StorageType.Register:
        return True

    if schedule in [
            ScheduleType.GPU_Device,
            ScheduleType.GPU_Persistent,
            ScheduleType.GPU_ThreadBlock,
            ScheduleType.GPU_ThreadBlock_Dynamic,
    ]:
        return storage in [StorageType.GPU_Global, StorageType.GPU_Shared, StorageType.CPU_Pinned]
    elif schedule in [ScheduleType.Default, ScheduleType.CPU_Multicore, ScheduleType.CPU_Persistent]:
        return storage in [
            StorageType.Default, StorageType.CPU_Heap, StorageType.CPU_Pinned, StorageType.CPU_ThreadLocal
        ]
    elif schedule == ScheduleType.Sequential:
        raise ValueError("Not well defined")


def can_allocate(storage: StorageType, schedule: ScheduleType):
    """
    Identifies whether a container of a storage type can be allocated in a
    specific schedule. Used to determine arguments to subgraphs by the
    innermost scope that a container can be allocated in. For example,
    GPU shared memory cannot be allocated outside of device-level code.

    :param storage: The storage type of the data container to allocate.
    :param schedule: The scope schedule to query.
    :return: True if the container can be allocated, False otherwise.
    """
    # Host-only allocation
    if storage in [StorageType.CPU_Heap, StorageType.CPU_Pinned, StorageType.CPU_ThreadLocal]:
        return schedule in [
            ScheduleType.CPU_Multicore,
            ScheduleType.CPU_Persistent,
            ScheduleType.Sequential,
            ScheduleType.MPI,
        ]

    # GPU-global memory
    if storage is StorageType.GPU_Global:
        return schedule in [
            ScheduleType.CPU_Multicore,
            ScheduleType.CPU_Persistent,
            ScheduleType.Sequential,
            ScheduleType.MPI,
        ]

    # GPU-local memory
    if storage == StorageType.GPU_Shared:
        return schedule in [
            ScheduleType.GPU_Device, ScheduleType.GPU_ThreadBlock, ScheduleType.GPU_ThreadBlock_Dynamic,
            ScheduleType.GPU_Persistent
        ]

    # The rest (Registers) can be allocated everywhere
    return True


def is_array(obj: Any) -> bool:
    """
    Returns True if an object implements the ``data_ptr()``,
    ``__array_interface__`` or ``__cuda_array_interface__`` standards
    (supported by NumPy, Numba, CuPy, PyTorch, etc.). If the interface is
    supported, pointers can be directly obtained using the
    ``array_interface_ptr`` function.

    :param obj: The given object.
    :return: True iff the object implements the array interface.
    """
    if isinstance(obj, type):
        return False
    try:
        if hasattr(obj, '__cuda_array_interface__'):
            return True
    except (KeyError, RuntimeError):
        # In PyTorch, accessing this attribute throws a runtime error for
        # variables that require grad, or KeyError when a boolean array is used
        return True
    if isinstance(obj, ctypes.Array):
        return True
    if hasattr(obj, '__array_interface__'):
        return len(obj.__array_interface__['shape']) > 0  # NumPy scalars contain an empty shape tuple
    if hasattr(obj, 'data_ptr'):
        try:
            return hasattr(obj, 'shape') and len(obj.shape) > 0
        except TypeError:  # PyTorch scalar objects define an attribute called shape that cannot be used
            return False
    if hasattr(obj, 'data') and hasattr(obj.data, 'ptr'):  # CuPy special case with HIP
        return True
    return False


def is_gpu_array(obj: Any) -> bool:
    """
    Returns True if an object is a GPU array, i.e., implements the
    ``__cuda_array_interface__`` standard (supported by Numba, CuPy, PyTorch,
    etc.). If the interface is supported, pointers can be directly obtained using the
    ``array_interface_ptr`` function.

    :param obj: The given object.
    :return: True iff the object implements the CUDA array interface.
    """
    try:
        if hasattr(obj, '__cuda_array_interface__'):
            return True
    except (KeyError, RuntimeError):
        # In PyTorch, accessing this attribute throws a runtime error for
        # variables that require grad, or KeyError when a boolean array is used
        return False

    if hasattr(obj, 'data') and hasattr(obj.data, 'ptr'):  # CuPy special case with HIP
        if hasattr(obj, 'device') and getattr(obj.device, 'id', -1) >= 0:
            return True

    return False


def array_interface_ptr(array: Any, storage: StorageType) -> int:
    """
    If the given array implements ``__array_interface__`` (see
    ``dtypes.is_array``), returns the base host or device pointer to the
    array's allocated memory.

    :param array: Array object that implements NumPy's array interface.
    :param array_type: Storage location of the array, used to determine whether
                       it is a host or device pointer (e.g. GPU).
    :return: A pointer to the base location of the allocated buffer.
    """
    if hasattr(array, 'data_ptr'):
        return array.data_ptr()
    if isinstance(array, ctypes.Array):
        return ctypes.addressof(array)

    if storage == StorageType.GPU_Global:
        try:
            return array.__cuda_array_interface__['data'][0]
        except AttributeError:
            # Special case for CuPy with HIP
            if hasattr(array, 'data') and hasattr(array.data, 'ptr'):
                return array.data.ptr
            raise

    return array.__array_interface__['data'][0]
